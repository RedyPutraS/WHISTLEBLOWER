<!DOCTYPE html>
<html lang="id">

<head>
	<title>Whistleblower &#8211; MNK</title>

	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />

	<link rel="dns-prefetch" href="http://s.w.org/" />
	<link rel="alternate" type="application/rss+xml" title="MNK &raquo; Feed" href="https://mnk.co.id/feed/" />
	<link rel="alternate" type="application/rss+xml" title="MNK &raquo; Comments Feed" href="https://mnk.co.id/comments/feed/" />

	<link rel="stylesheet" id="wp-block-library-css" href="<?php echo e(asset('assets/front/wp-includes/css/dist/block-library/style.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="contact-form-7-css" href="<?php echo e(asset('assets/front/wp-content/plugins/contact-form-7/includes/css/styles7752.css')); ?>" media="all" />
	<link rel="stylesheet" id="rs-plugin-settings-css" href="<?php echo e(asset('assets/front/wp-content/plugins/revslider/public/assets/css/rs63781.css')); ?>" media="all" />
	<link rel="stylesheet" id="font-awesome-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/font-awesome/css/font-awesome.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="themify-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/themify-icons/themify-iconsc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="perfect-scrollbar-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/perfect-scrollbar/perfect-scrollbar.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="chrisbracco-tooltip-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/chrisbracco-tooltip/chrisbracco-tooltip.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="multi-columns-row-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/multi-columns-rowc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="select2-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/select2/select2.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="flexslider-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/bower/flexslider/flexslider.min9b2d.css')); ?>" media="all" />
	<link rel="stylesheet" id="cymolthemes-duplexo-icons-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/cmt-duplexo-icons/css/cmt-duplexo-iconsc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="cymolthemes-duplexo-extra-icons-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/cymolthemes-duplexo-extra-icons/font/flaticonc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="slick-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/slick/slickc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="slick-theme-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/slick/slick-themec4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="prettyphoto-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/prettyphoto/css/prettyPhoto.min9b2d.css')); ?>" media="all" />
	<link rel="stylesheet" id="js_composer_front-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/css/js_composer.min9b2d.css')); ?>" media="all" />
	<link rel="stylesheet" id="bootstrap-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/bootstrap.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="bootstrap-theme-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/bootstrap-theme.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="js-composer-tta-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/css/js_composer_tta.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="duplexo-shortcode-style-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/shortcode.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="duplexo-core-style-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/core.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="duplexo-responsive-style-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/responsive.minc4ec.css')); ?>" media="all" />
	<link rel="stylesheet" id="theme-last-checkpoint-css" href="<?php echo e(asset('assets/front/wp-content/themes/duplexo/css/theme-last-checkpoint.minc4ec.css')); ?>" media="all" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,400i,500,500i,600,600i,700,700i&amp;display=swap" rel="stylesheet" />
    <link rel="stylesheet" id="vc_pageable_owl-carousel-css-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/owl-carousel2-dist/assets/owl.min9b2d.css')); ?>" media="all" />
	<link rel="stylesheet" id="vc_animate-css-css" href="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/bower/animate-css/animate.min9b2d.css')); ?>" media="all" />
	<link rel="stylesheet" id="cymolthemes-cs-google-fonts-css" href="http://fonts.googleapis.com/css?family=Work+Sans%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900%7CPoppins%3A600%2C400%2C500%7CRoboto+Condensed%3A400%7CRoboto%3A400%7CArimo%3A400%7CJosefin+Sans%3A600" media="all" />
	<link rel="stylesheet" id="cymolthemes-footer-gfonts-css" href="http://fonts.googleapis.com/css?family=Abril+Fatface%3Aregular&amp;ver=5.4') }}" media="all" />

	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
	<meta name="generator" content="Powered by Slider Revolution 6.2.2 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
	<link rel="icon" href="<?php echo e(asset('assets/front/wp-content/uploads/2020/07/cropped-logomnk-32x32.png')); ?>" sizes="32x32" />
	<link rel="icon" href="<?php echo e(asset('assets/front/wp-content/uploads/2020/07/cropped-logomnk-192x192.png')); ?>" sizes="192x192" />
	<link rel="apple-touch-icon" href="<?php echo e(asset('assets/front/wp-content/uploads/2020/07/cropped-logomnk-180x180.png')); ?>" />
	<meta name="msapplication-TileImage" content="https://mnk.co.id/wp-content/uploads/2020/07/cropped-logomnk-270x270.png') }}" />

    <link rel="stylesheet" id="main-css" href="<?php echo e(asset('assets/front/css/main.css')); ?>" media="all" />
    <link rel="stylesheet" id="style" href="<?php echo e(asset('assets/front/style.css')); ?>" media="all" />
</head>

<body
	class="page-template-default page page-id-63 headerstyle-four cymolthemes-sticky-footer cymolthemes-wide cymolthemes-page-full-width cmt-sboxempty-sidebar wpb-js-composer js-comp-ver-6.1 vc_responsive">
	<div id="cmt-home"></div>
	<div class="main-holder">
		<div id="page" class="hfeed site">
			<header id="cmt-page-header" class="header-style-four cmt-main-menu-total-8 cmt-main-menu-more-than-six">
				<div class="cmt-header-box cmt-mmenu-active-color-skin cmt-submenu-active-skin cmt-submenu-sep-grey">
					<div id="site-header" class="site-header cmt-bgcolor-white cmt-sticky-bgcolor-darkgrey cmt-mmmenu-override-yes cmt-sboxabove-content-yes">
						<div class="site-header-main cmt-section-wrapper">
							<div class="cmt-sboxheader-top-wrapper container cmt-container-for-header">
								<div class="site-branding">
									<div class="headerlogo cymolthemes-logotype-image cmt-sboxstickylogo-no">
										<span class="site-title">
											<a class="home-link" href="https://mnk.co.id/" title="MNK" rel="home">
												<span class="cmt-sboxsc-logo cmt-sboxsc-logo-type-image">
                                                    <img class="cymolthemes-logo-img standardlogo" alt="MNK" src="http://127.0.0.1:8000/assets/front/wp-content/uploads/2020/07/logomnk.png">
                                                </span>
											</a>
										</span>
										<h2 class="site-description">PT. Multi Nitrotama Kimia</h2>
									</div>
								</div>
								<div class="cmt-sboxtop-info-con">
									<div class="header-widget">
										<div class="header-widget-main">
											<div class="header-icon">
												<div class="icon">
													<i class="cmt_duplexo flaticon-phone-call"></i>
												</div>
											</div>
											<div class="header-content">
												<h3>Call Us</h3>
												<h5>(+62-21) 2903 5022</h5>
											</div>
										</div>
									</div>
									<div class="header-widget">
										<div class="header-widget-main">
											<div class="header-icon">
												<div class="icon">
													<i class="cmt_duplexo flaticon-email"></i>
												</div>
											</div>
											<div class="header-content">
												<h3>Send Us Email</h3>
												<h5>company.info@mnk.co.id</h5>
											</div>
										</div>
									</div>
									<div class="header-widget">
										<div class="header-widget-main">
											<a class="home-link" href="https://mnk.co.id/" title="MNK">
												<img class="cymolthemes-logo-img standardlogo" alt="MNK" src="http://127.0.0.1:8000/assets/front/wp-content/uploads/2020/07/logoiso.png">
											</a>
										</div>
									</div>
								</div>
							</div>
							<div id="cmt-stickable-wrapper" class="cmt-stickable-wrapper cmt-bgcolor-white" style="height:65px">
                                <div id="site-header-menu" class="site-header-menu">
                                    <div class="site-header-menu-inner cmt-sboxstickable-header  cmt-header-menu-bg-color-darkgrey cmt-bgcolor-darkgrey cmt-sticky-bgcolor-darkgrey" style="">
                                        <div class="container cmt-container-for-header ">
                                            <div class="site-header-menu-middle">
                                                <div>
                                                    <nav id="site-navigation" class="main-navigation" aria-label="Primary Menu" data-sticky-height="70">	
                                                        <button id="menu-toggle" class="menu-toggle">
                                                            <span class="cmt-hide">
                                                                Toggle menu
                                                            </span>
                                                            <i class="cmt-duplexo-icon-bars"></i>
                                                        </button>
                                                        <div class="nav-menu">
                                                            <ul id="menu-utama" class="nav-menu">
                                                                <li id="menu-item-26" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-26">
                                                                    <a href="https://mnk.co.id/">
                                                                        Home
                                                                    </a>
                                                                </li>
                                                                <li id="menu-item-27" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-27">
                                                                    <a href="https://mnk.co.id/about-us/">
                                                                        About Us
                                                                    </a>
                                                                    <ul class="sub-menu">
                                                                        <li id="menu-item-39" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-39">
                                                                            <a href="https://mnk.co.id/overview/">
                                                                                Overview
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42">
                                                                            <a href="https://mnk.co.id/history/">
                                                                                History
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-30" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30">
                                                                            <a href="https://mnk.co.id/board-of-directors/">
                                                                                Board Of Directors
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                </li>
                                                                <li id="menu-item-50" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-50">
                                                                    <a href="#">
                                                                        Product & Services
                                                                    </a>
                                                                    <ul class="sub-menu">
                                                                        <li id="menu-item-51" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-51">
                                                                            <a href="https://mnk.co.id/service/product/">
                                                                                Product
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-53">
                                                                            <a href="https://mnk.co.id/service/bulk-explosives/">
                                                                                Bulk Explosives
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-57">
                                                                            <a href="https://mnk.co.id/service/explosives-accessories/">
                                                                                Explosives Accessories
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-56">
                                                                            <a href="https://mnk.co.id/service/services/">
                                                                                Services
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                </li>
                                                                <li id="menu-item-62" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-62">
                                                                    <a href="#">
                                                                        Supply Chain
                                                                    </a>
                                                                    <ul class="sub-menu">
                                                                        <li id="menu-item-61" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-61">
                                                                            <a href="https://mnk.co.id/service/import/">
                                                                                Import
                                                                            </a>
                                                                        </li>
                                                                        <li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-cmt_service menu-item-60">
                                                                            <a href="https://mnk.co.id/service/explosives-transport-licensing/">
                                                                                Explosives Transport & Licensing
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                    <span class="righticon">
                                                                        <i class="cmt-duplexo-icon-angle-down"></i>
                                                                    </span>
                                                                </li>
                                                                <li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-63 menu-item-65">
                                                                    <a href="index.html">
                                                                        Program CSR
                                                                    </a>
                                                                </li>
                                                                <li id="menu-item-67" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-67">
                                                                    <a href="https://sfid.dataon.com/sf6/index.cfm">
                                                                        HRIS SYSTEM
                                                                    </a>
                                                                </li>
                                                                <li id="menu-item-1933" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1933">
                                                                    <a href="https://mnk.co.id/news/">
                                                                        News
                                                                    </a>
                                                                </li>
                                                                <li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-70 lastsecond">
                                                                    <a href="https://mnk.co.id/contact-us/" aria-current="page">
                                                                        Contact Us
                                                                    </a>
                                                                </li>
                                                                <li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-70 last current_page_item">
                                                                    <a href="https://mnk.co.id/contact-us/">
                                                                        Whistleblower
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>									
                                                        <div class="kw-phone">
                                                            <div class="tcmt-sboxcustombutton">
                                                                <div class="cmt-rt-icon">
                                                                    <i class="ti ti-files"></i>
                                                                </div>
                                                                <div class="cmt-custombutton">
                                                                    <p>Need Estimate?</p>
                                                                    <a href="mailto:company.info@mnk.co.id">
                                                                        Request A Quote
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>				
                                    </div>
                                </div>
                            </div>
						</div>
					</div>
					<div class="cmt-title-wrapper cmt-bg cmt-bgcolor-custom cmt-titlebar-align-default cmt-textcolor-white cmt-bgimage-yes cmt-breadcrumb-bgcolor-custom">
						<div class="cmt-title-wrapper-bg-layer cmt-bg-layer"></div>
						<div class="cmt-titlebar entry-header">
							<div class="cmt-titlebar-inner-wrapper">
								<div class="cmt-titlebar-main">
									<div class="container">
										<div class="cmt-titlebar-main-inner">
											<div class="entry-title-wrapper">
												<div class="container">
													<h1 class="entry-title">
                                                        Whistleblower
                                                    </h1>
												</div>
											</div>
											<div class="breadcrumb-wrapper">
												<div class="container">
													<div class="breadcrumb-wrapper-inner">
														<span>
															<a title="Go to MNK." href="https://mnk.co.id/" class="home">
                                                                <span>MNK</span>
                                                            </a>
														</span>
														&gt;
                                                        <span>
                                                            <span class="post post-page current-item">
                                                                Whistleblower
                                                            </span>
                                                        </span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<div id="content-wrapper" class="site-content-wrapper">
				<div id="content" class="site-content">
					<div id="content-inner" class="site-content-inner">
						<div id="primary" class="content-area">
							<main id="main" class="site-main">
								<article id="post-63" class="post-63 page type-page status-publish hentry">
									<header class="single-entry-header cmt-hide">
										<h2 class="entry-title">
                                            Whistleblower
                                        </h2>
									</header>
									<div class="entry-content container">
                                        Ini isinya ygy
										<div class="vc_row-full-width vc_clearfix"></div>
									</div>
								</article>
							</main>
						</div>
					</div>
				</div>
			</div>
			<footer id="colophon" class="site-footer">
				<div class="footer_inner_wrapper footer cmt-bg cmt-bgcolor-transparent cmt-bgimage-yes">
					<div class="site-footer-bg-layer cmt-bg-layer"></div>
					<div class="site-footer-w">
						<div class="footer-rows">
							<div class="footer-rows-inner">
								<div id="first-footer"
									class="sidebar-container first-footer cmt-bg cmt-bgcolor-custom cmt-textcolor-white cmt-bgimage-no"
									role="complementary">
									<div class="first-footer-bg-layer cmt-bg-layer"></div>
									<div class="container cmt-container-for-footer">
										<div class="first-footer-inner">
											<div class="row multi-columns-row">
												<div class="widget-area col-xs-12 col-sm-6 col-md-3 col-lg-3">
													<aside id="text-2" class="widget-even widget-2 widget widget_text">
														<h3 class="widget-title">Head Office</h3>
														<div class="textwidget">
															<p>
																Equity Tower 41st Floor Suite A<br />
																Sudirman Central Business Disctrict (SCBD)<br />
																Jl. Jend. Sudirman Kav. 52-53 Lot 9 Jakarta 12190<br />
																Telp : (+62-21) 2903 5022<br />
																Fax : (+62-21) 2903 5021
															</p>
														</div>
													</aside>
												</div>
												<div class="widget-area col-xs-12 col-sm-6 col-md-3 col-lg-3">
													<aside id="text-3" class="widget-even widget-2 widget widget_text">
														<h3 class="widget-title">Plant Site</h3>
														<div class="textwidget">
															<p>
																Kawasan Industri Kujang Cikampek<br />
																Jl. Jend. A. Yani, Dawuan<br />
																Cikampek, Jawa Barat 41373<br />
																Telp : (+62-264) 313700<br />
																Fax : (+62-264) 313389
															</p>
														</div>
													</aside>
												</div>
												<div class="widget-area col-xs-12 col-sm-6 col-md-3 col-lg-3">
													<aside id="text-4" class="widget-even widget-2 widget widget_text">
														<h3 class="widget-title">Operational Office</h3>
														<div class="textwidget">
															<p>
																Jl. Kol. Syarifoedin Yoes No. 69 Balikpapan<br />
																Kalimantan Timur 76115<br />
																Telp : (+62-542) 8520 519,<br />
																(+62-542) 8520 520<br />
																Fax : (+62-542) 8520 521
															</p>
														</div>
													</aside>
												</div>
												<div class="widget-area col-xs-12 col-sm-6 col-md-3 col-lg-3">
													<aside id="text-5" class="widget-even widget-2 widget widget_text">
														<h3 class="widget-title">Pusat Teknologi Terpadu</h3>
														<div class="textwidget">
															<p>
																Jln. Husni Thamrin RT.08<br />
																Kel. Muara Kembang Dalam<br />
																Kec. Muara Jawa<br />
																Kab. Kutai Kartanegara &#8211; 75261<br />
																Telp. 0541 691571
															</p>
														</div>
													</aside>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div id="bottom-footer-text"
							class="bottom-footer-text cmt-sboxbottom-footer-text site-info cmt-bg cmt-bgcolor-custom cmt-textcolor-white cmt-bgimage-no">
							<div class="bottom-footer-bg-layer cmt-bg-layer"></div>
							<div class="container cmt-container-for-footer">
								<div class="bottom-footer-inner">
									<div class="row multi-columns-row">
										<div class="col-xs-12 col-sm-7 cmt-footer2-left">
                                            Copyright © 2022 
                                            <a href="https://mnk.co.id/">MNK</a>
                                            All rights reserved.
                                        </div>
										<div class="col-xs-12 col-sm-5 cmt-footer2-right">
											<div class="cymolthemes-social-links-wrapper">
												<ul class="social-icons">
													<li class="cmt-social-facebook">
														<a class="tooltip-top" target="_blank" href="#" data-tooltip="Facebook">
                                                            <i class="cmt-duplexo-icon-facebook"></i>
                                                        </a>
													</li>
													<li class="cmt-social-twitter">
														<a class="tooltip-top" target="_blank" href="#" data-tooltip="Twitter">
                                                            <i class="cmt-duplexo-icon-twitter"></i>
                                                        </a>
													</li>
													<li class="cmt-social-flickr">
														<a class="tooltip-top" target="_blank" href="#" data-tooltip="Flickr">
                                                            <i class="cmt-duplexo-icon-flickr"></i>
                                                        </a>
													</li>
													<li class="cmt-social-linkedin">
														<a class="tooltip-top" target="_blank" href="#" data-tooltip="LinkedIn">
                                                            <i class="cmt-duplexo-icon-linkedin"></i>
                                                        </a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<a id="scroll_up" href="#top">
        <i class="cmt-duplexo-icon-angle-up"></i>
    </a>

    <script src="<?php echo e(asset('assets/front/wp-includes/js/jquery/jquery4a5f.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-includes/js/jquery/jquery-migrate.min330a.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/revslider/public/assets/js/rbtools.minf049.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/revslider/public/assets/js/rs6.min3781.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/themeextras-for-duplexotheme/js/jquery-resize.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/contact-form-7/includes/js/scripts7752.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/perfect-scrollbar/perfect-scrollbar.jquery.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/select2/select2.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/isotope/isotope.pkgd.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/jquery-mousewheel/jquery.mousewheel.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/flexslider/jquery.flexslider-minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/sticky-kit/jquery.sticky-kit.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/assets/slick/slick.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/prettyphoto/js/jquery.prettyPhoto.min9b2d.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min9b2d.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/themes/duplexo/js/main.min5152.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-includes/js/wp-embed.minc4ec.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/owl-carousel2-dist/owl.carousel.min9b2d.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/bower/imagesloaded/imagesloaded.pkgd.min9b2d.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-includes/js/underscore.min4511.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/lib/vc_waypoints/vc-waypoints.min9b2d.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/wp-content/plugins/js_composer/assets/js/dist/vc_grid.min9b2d.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH D:\Project\Web\Whistleblower\resources\views/master/base.blade.php ENDPATH**/ ?>