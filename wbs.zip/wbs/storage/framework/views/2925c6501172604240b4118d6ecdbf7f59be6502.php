<?php $__env->startSection('content'); ?>
    <div class="content__header content__boxed overlapping mb-4">
        <div class="content__wrap">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="ri-home-4-line"></i>
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Profil
                    </li>
                </ol>
            </nav>
            <h1 class="page-title mt-4">
                Profil
            </h1>
            <p class="lead">
                Profil pengguna
            </p>
        </div>
    </div>
    <div class="content__boxed">
        <div class="content__wrap">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <?php echo e(Session::get('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-xl-8 my-1">
                                    <h4 class="fw-bold mb-0 text-primary">
                                        Data Akun
                                    </h4>
                                </div>
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('user.profileupdate',Crypt::encrypt($user->u_id))); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>
                                        Nama
                                        <span class="text-danger font-weight-bold">*</span>
                                    </label>
                                    <input type="text" name="u_nama" id="u_nama" class="form-control" value="<?php echo e($user->u_nama); ?>" readonly>
                                    <?php $__errorArgs = ['u_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>
                                        Username
                                        <span class="text-danger font-weight-bold">*</span>
                                    </label>
                                    <input type="text" name="u_username" id="u_username" class="form-control" value="<?php echo e($user->u_username); ?>" readonly required>
                                    <?php $__errorArgs = ['u_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>
                                        Email
                                        <span class="text-danger font-weight-bold">*</span>
                                    </label>
                                    <input type="email" name="u_email" id="u_email" class="form-control" value="<?php echo e($user->u_email); ?>" readonly required>
                                    <?php $__errorArgs = ['u_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="changepassword_container">
                                    <button type="button" class="btn btn-primary changepassword">
                                        <i class="ri-lock-2-fill align-middle me-1"></i>
                                        Ubah Password?
                                        <span class="ml-1 font-weight-bold changepassword_text changepassword_text_yes d-none">Ya</span>
                                        <span class="ml-1 font-weight-bold changepassword_text changepassword_text_no">Tidak</span>
                                    </button>
                                    <div class="changepasswordform mt-2">
                                        <?php if(Session::has('oldpassword') || Session::has('newpassword')): ?>
                                            <div class="form-group row">
                                                <div class="col-md-2">
                                                    <label>
                                                        Password Lama
                                                        <span class="text-danger font-weight-bold">*</span>
                                                    </label>
                                                    <?php if(Session::has('oldpassword')): ?>
                                                        <div class="text-danger">
                                                            <?php echo e(Session::get('oldpassword')); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-10">
                                                    <input type="password" name="oldpassword" id="oldpassword" class="form-control <?php if(Session::has('oldpassword')): ?> is-invalid <?php endif; ?>">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-2">
                                                    <label>
                                                        Password Baru
                                                        <span class="text-danger font-weight-bold">*</span>
                                                    </label>
                                                    <?php if(Session::has('newpassword')): ?>
                                                        <div class="text-danger">
                                                            <?php echo e(Session::get('newpassword')); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-md-10">
                                                    <input type="password" name="newpassword" id="newpassword" class="form-control <?php if(Session::has('newpassword')): ?> is-invalid <?php endif; ?>">
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="mt-5 text-right">
                                    <a href="<?php echo e(route('role.index')); ?>" class="btn btn-dark me-2">
                                        <i class="ri-save-2-fill align-bottom me-1"></i>
                                        Batal
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="ri-delete-bin-fill align-bottom me-1"></i>
                                        Simpan
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.changepassword_container').on('click', '.changepassword', function() {
            $('.changepassword_text_yes').toggleClass('d-none');
            $('.changepassword_text_no').toggleClass('d-none');
            var html = `
                <div class="form-group row">
                    <div class="col-md-2">
                        <label>
                            Password Lama
                            <span class="text-danger font-weight-bold">*</span>
                        </label>
                        <?php $__errorArgs = ['oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-10">
                        <input type="password" name="oldpassword" id="oldpassword" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2">
                        <label>
                            Password Baru
                            <span class="text-danger font-weight-bold">*</span>
                        </label>
                    </div>
                    <div class="col-md-10">
                        <input type="password" name="newpassword" id="newpassword" class="form-control">
                    </div>
                </div>
            `;
            if ($('.changepasswordform').html() == html) {
                $('.changepasswordform').html("");
            } 
            else {
                $('.changepasswordform').html(html);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/dashboard/profile/index.blade.php ENDPATH**/ ?>