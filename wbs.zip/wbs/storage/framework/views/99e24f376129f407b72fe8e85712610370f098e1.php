<?php $__env->startSection('content'); ?>
    <div class="content__header content__boxed overlapping mb-4">
        <div class="content__wrap">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="ri-home-4-line"></i>
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Pengaturan
                    </li>
                </ol>
            </nav>
            <h1 class="page-title mt-4">
                Pengaturan
            </h1>
            <p class="lead">
                Atur konfigurasi yang dibutuhkan di dalam aplikasi
            </p>
        </div>
    </div>
    <div class="content__boxed">
        <div class="content__wrap">
            <div class="row">
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 my-2">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="fw-bold mb-4">
                                    <?php echo e($setting->pgtr_label); ?>

                                </h4>
                                <form action="<?php echo e(route('setting.update')); ?>" method="post">
                                    <?php $__currentLoopData = $setting->config; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="form-group row align-items-center">
                                            <div class="col-md-2">
                                                <label class="form-label">
                                                    <?php echo e($config->pgtr_nama); ?>

                                                    <span class="text-danger font-weight-bold">*</span>
                                                </label>
                                            </div>
                                            <div class="col-md-10">
                                                <input type="hidden" name="pgtr_id[]" value="<?php echo e($config->pgtr_id); ?>">
                                                <?php if($config->pgtr_input_type == 'tags'): ?>
                                                    <input type="text" name="pgtr_nilai" class="form-control tagin" value="<?php echo e($config->pgtr_nilai); ?>">
                                                <?php else: ?>
                                                    <input type="<?php echo e($config->pgtr_input_type); ?>" name="pgtr_nilai[]" class="form-control" value="<?php echo e($config->pgtr_nilai); ?>">
                                                <?php endif; ?>
                                                <?php if($config->pgtr_note): ?>
                                                    <p class="my-1">
                                                        Note: <?php echo e($config->pgtr_note); ?>

                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-3 text-end">
                                        <button type="submit" class="btn btn-lg btn-primary">
                                            <i class="bx bxs-save align-middle fs-4 me-1"></i>
                                            Simpan
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/tags.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/tags.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/dashboard/setting/index.blade.php ENDPATH**/ ?>