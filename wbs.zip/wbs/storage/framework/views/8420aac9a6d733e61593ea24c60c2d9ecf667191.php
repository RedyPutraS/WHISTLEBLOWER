<?php $__env->startSection('content'); ?>
    <article class="post-63 page type-page status-publish hentry">
        <div class="entry-content container">
            <ul class="nav nav-tabs">
                <li class="nav-item active">
                    <a id="detailreport" class="nav-link" aria-current="page" >
                        Detail
                    </a>
                </li>
                <li class="nav-item">
                    <a id="resultreport" class="nav-link">
                        Progress
                    </a>
                </li>
                <li class="nav-item">
                    <a id="askquestion" class="nav-link">
                        Tanya Tim
                    </a>
                </li>
            </ul>
            <div class="tab-content clearfix py-5">
                <div class="tab-pane active" id="1a">
                    <div class="row">
                        <div class="col-md-9 my-2">
                            <h4 class="vc_custom_heading">
                                <?php if($cms['Judul']): ?>
                                    <?php echo $cms['Judul']; ?>

                                <?php else: ?>
                                    Rincian Pengaduan
                                <?php endif; ?>
                                No. <?php echo e($report->f_noreg); ?>

                            </h4>
                            
                            <div class="my-2">
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                Nama & Instansi Pelapor
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($report->f_nama): ?>
                                            <?php echo e($report->f_nama); ?>

                                        <?php else: ?>
                                            Anonim [Identitas Dirahasiakan]
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                No. Telepon/HP
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($report->f_no_telepon): ?>
                                            <?php echo e($report->f_no_telepon); ?>

                                        <?php else: ?>
                                            Anonim [Identitas Dirahasiakan]
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                Email
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($report->f_email): ?>
                                            <?php echo e($report->f_email); ?>

                                        <?php else: ?>
                                            Anonim [Identitas Dirahasiakan]
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                Waktu Kejadian
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php echo e($report->f_waktu_kejadian); ?>

                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                Tempat Kejadian
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php echo e($report->f_tempat_kejadian); ?>

                                    </div>
                                </div>
                                <div class="row my-2">
                                    <div class="col-md-4">
                                        <div class="row">
                                            <label class="col-10">
                                                Kronologi
                                            </label>
                                            <div class="col-2 d-none d-lg-block font-weight-bold">
                                                :
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php echo $report->f_kronologi; ?>

                                    </div>
                                </div>
                                <?php if(count($report->formulirpengaduan_buktiawal) > 0): ?>
                                    <div class="row my-2">
                                        <div class="col-md-4">
                                            <div class="row">
                                                <label class="col-10">
                                                    Bukti Awal
                                                </label>
                                                <div class="col-2 d-none d-lg-block font-weight-bold">
                                                    :
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <?php $__currentLoopData = $report->formulirpengaduan_buktiawal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="<?php echo e($evidence->attachment); ?>" target="_blank" class="btn btn-flat" style="font-size: 12px;">
                                                    <i class="fa fa-fw fa-eye mr-1"></i>
                                                    Bukti <?php echo e($index+1); ?>

                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if(count($report->formulirpengaduan_buktitambahan) > 0): ?>
                                    <?php $__currentLoopData = $report->formulirpengaduan_buktitambahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <hr>
                                        <div class="row my-2">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <label class="col-10">
                                                        Bukti Tambahan
                                                    </label>
                                                    <div class="col-2 d-none d-lg-block font-weight-bold">
                                                        :
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <a href="<?php echo e($evidence->attachment); ?>" target="_blank" class="btn btn-flat" style="font-size: 12px;">
                                                    <i class="fa fa-fw fa-eye mr-1"></i>
                                                    Bukti <?php echo e($index+1); ?>

                                                </a>
                                            </div>
                                        </div>
                                        <div class="row my-2">
                                            <div class="col-md-4">
                                                <div class="row">
                                                    <label class="col-10">
                                                        Keterangan Tambahan
                                                    </label>
                                                    <div class="col-2 d-none d-lg-block font-weight-bold">
                                                        :
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <?php if($evidence->fb_keterangan): ?>
                                                    <?php echo e($evidence->fb_keterangan); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3 my-2">
                            <div class="p-3 w-100 font-weight-bold text-center" style="background: <?php echo e($report->status->s_warna_background); ?>; color: <?php echo e($report->status->s_warna_teks); ?>;">
                                <?php echo e($report->status->s_nama); ?> <br>
                                <?php echo e(\Carbon\Carbon::parse($report->formulirpengaduan_riwayatterbaru->created_at)->translatedFormat('d M Y H:i')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>

    <div class="modal fade" id="form-modal-evidence" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body p-4" id="evidence">
                    <p><strong>Lihat Bukti</strong></p>
                </div>
                <div class="modal-footer">
                    <div class="mt-4 pull-right d-flex">
                        <button type="button" class="close-evidence btn btn-danger px-4 mr-2" style="min-width:70px;font-size: 1.5rem!important;">
                            Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="form-modal-token" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <form action="#" method="post" id="showbuktiform">
                        <div class="form-group">
                            <label>
                                Masukkan Token
                            </label>
                            <input type="hidden" id="action" name="action" value="">
                            <input type="text" name="f_token" id="f_token" value="">
                        </div>
                        <div class="mt-4 pull-right d-flex">
                            <button type="button" class="close btn btn-danger px-4 mr-2" style="min-width:70px;font-size: 1.5rem!important;">
                                Tutup
                            </button>
                            <button type="button" id="submit" class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3 cmt-vc_btn3-color-black" style="min-width:70px;">
                                Submit
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('helpers/js/fronthelpers.js')); ?>"></script>
<script>
    var checksession =  checksession(token,checkurl,"<?php echo e($report->f_noreg); ?>");
    $('#detailreport').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('detailreport');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
    });

    $('#resultreport').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('resultreport');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
    });

    $('#askquestion').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('askquestion');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
        });

        $('#submit').on('click',function (e) { 
        e.preventDefault();
        urlref();
    });

    function urlref() { 
        var f_noreg = "<?php echo e($report->f_noreg); ?>";
        var f_token = $('#f_token').val();
        var action = $('#action').val();

        $.ajax({
            type: "POST",
            url: "<?php echo e(route('tokenverification')); ?>",
            data: {
                _token:'<?php echo e(csrf_token()); ?>',
                f_token:f_token,
                f_noreg:f_noreg,
                action:action
            },
            dataType: "json",
            success: function (response) {
                if(response.result){
                    var url = response.data.url;
                    location.href = url; 
                }else{
                    $('#form-modal-token').toggleClass('show');
                    $('#f_token').val('');
                    Swal.fire({
                        icon: 'error',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                }
            }
        });
    }

</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/front/detailreport.blade.php ENDPATH**/ ?>