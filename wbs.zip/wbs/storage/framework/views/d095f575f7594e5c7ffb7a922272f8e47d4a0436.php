<?php $__env->startSection('content'); ?>
    <article class="post-63 page type-page status-publish hentry">
        <div class="entry-content container">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a id="detailreport" class="nav-link" aria-current="page" >
                        Detail
                    </a>
                </li>
                <li class="nav-item ">
                    <a id="resultreport" class="nav-link">
                        Progress
                    </a>
                </li>
                <li class="nav-item active">
                    <a id="askquestion" class="nav-link">
                        Tanya Tim
                    </a>
                </li>
            </ul>
            <div class="tab-content clearfix py-5">
                <div class="tab-pane active" id="1a">
                    <h4 class="vc_custom_heading">
                        <?php if($cms['Judul']): ?>
                            <?php echo $cms['Judul']; ?>

                        <?php else: ?>
                            Tanya Tim Investigator
                        <?php endif; ?>
                    </h4>
                    <form action="<?php echo e(route('sentaskquestion',Crypt::encrypt($report->f_id))); ?>" method="post" class="my-4">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <textarea name="question" id="question" class="form-control" rows="7" placeholder="Kirim pesan..."><?php echo e(old('question')); ?></textarea>
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="text-right">
                            <button type="submit" class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3 cmt-vc_btn3-color-black">
                                Kirim
                            </button>
                        </div>
                    </form>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($message->rd_tipe_user == 'PELAPOR'): ?>
                        <div class="card my-4 shadow">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="col-md-1 w-auto">
                                        <i class="fa fa-fw fa-user" style="font-size: 45px;"></i>
                                    </div>
                                    <div class="col-md-11">
                                        <div class="row">
                                            <div class="col-md-10 px-0">
                                                <h6 class="mb-2">
                                                    <?php echo e($message->created_by); ?>

                                                </h6>
                                            </div>
                                            <div class="col-md-2 mb-4 px-0 text-lg-right">
                                                <?php echo e(\Carbon\Carbon::parse($message->created_at)->translatedFormat('d F Y H:i')); ?>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <p>
                                                <?php echo e($message->rd_pesan); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                            <div class="card my-4 shadow">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="col-md-1 w-auto">
                                            <i class="fa fa-fw fa-users" style="font-size: 45px;"></i>
                                        </div>
                                        <div class="col-md-11">
                                            <div class="row">
                                                <div class="col-md-10 px-0">
                                                    <h6 class="mb-2">
                                                        <?php echo e($message->created_by); ?>

                                                    </h6>
                                                </div>
                                                <div class="col-md-2 mb-4 px-0 text-lg-right">
                                                    <?php echo e(\Carbon\Carbon::parse($message->created_at)->translatedFormat('d F Y H:i')); ?>

                                                </div>
                                            </div>
                                            <div class="row">
                                                <p>
                                                    <?php echo e($message->rd_pesan); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>

        <div class="modal fade" id="form-modal-token" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body p-4">
                        <form action="#" method="post" id="showbuktiform">
                            <div class="form-group">
                                <label>
                                    Masukkan Token
                                </label>
                                <input type="hidden" id="action" name="action" value="">
                                <input type="text" name="f_token" id="f_token" value="">
                            </div>
                            <div class="mt-4 pull-right d-flex">
                                <button type="button" class="close btn btn-danger px-4 mr-2" style="min-width:70px;font-size: 1.5rem!important;">
                                    Tutup
                                </button>
                                <button type="button" id="submit" class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3 cmt-vc_btn3-color-black" style="min-width:70px;">
                                    Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('helpers/js/fronthelpers.js')); ?>"></script>
<script>
    var checksession =  checksession(token,checkurl,"<?php echo e($report->f_noreg); ?>");
    $('#detailreport').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('detailreport');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
    });

    $('#resultreport').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('resultreport');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
    });

    $('#askquestion').on('click',function (e) { 
        e.preventDefault();
        $('#action').val('askquestion');
        if(checksession.success){
            $('#f_token').val(checksession.data);
            urlref();
        }else{
            $('#form-modal-token').toggleClass('show');
        }
        });

        $('#submit').on('click',function (e) { 
        e.preventDefault();
        urlref();
    });

    function urlref() { 
        var f_noreg = "<?php echo e($report->f_noreg); ?>";
        var f_token = $('#f_token').val();
        var action = $('#action').val();

        $.ajax({
            type: "POST",
            url: "<?php echo e(route('tokenverification')); ?>",
            data: {
                _token:'<?php echo e(csrf_token()); ?>',
                f_token:f_token,
                f_noreg:f_noreg,
                action:action
            },
            dataType: "json",
            success: function (response) {
                if(response.result){
                    var url = response.data.url;
                    location.href = url; 
                }else{
                    $('#form-modal-token').toggleClass('show');
                    $('#f_token').val('');
                    Swal.fire({
                        icon: 'error',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                }
            }
        });
        }

</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/front/askquestion.blade.php ENDPATH**/ ?>