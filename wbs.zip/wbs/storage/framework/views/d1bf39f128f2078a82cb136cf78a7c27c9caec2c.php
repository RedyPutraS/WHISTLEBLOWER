<?php $__env->startSection('content'); ?>
    <div class="content__header content__boxed overlapping mb-4">
        <div class="content__wrap">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="ri-home-4-line"></i>
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Pengaduan via Email
                    </li>
                </ol>
            </nav>
            <h1 class="page-title mt-4">
                Pengaduan via Email
            </h1>
            <p class="lead">
                Pengaduan Masuk via Email
            </p>
        </div>
    </div>
    <div class="content__boxed">
        <div class="content__wrap">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-2">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <?php echo e(Session::get('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-xl-8 my-1">
                                    <h4 class="fw-bold mb-0">
                                        Pengaduan via Email
                                    </h4>
                                </div>
                                <div class="col-xl-4 text-lg-right my-1">
                                    <a href="<?php echo e(route('inbox.synchronize')); ?>" class="btn btn-primary btn-lg fw-bold">
                                        <i class="bx bx-sync align-middle fs-4 me-1"></i>
                                        Sinkronkan
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table table-bordered dataTable dt-responsive nowrap table-striped align-middle" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center" style="width:30px;">No</th>
                                            <th>Date</th>
                                            <th>Email</th>
                                            <th>Subject</th>
                                            <th style="width:50px;">Aksi</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/jquery.datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.buttons.colvis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/datatables/datatables.buttons.jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/moment-with-locales.js')); ?>"></script>
    <script src="<?php echo e(asset('helpers/js/serversidedatatables.js')); ?>"></script>
    <script src="<?php echo e(asset('helpers/js/formathelper.js')); ?>"></script>
    <script>
        var url = "<?php echo e(route('inbox.datatable')); ?>";
        var datatable = new Datatable({
            title: "Inbox Email",
            url: url,
            csrf: "<?php echo e(csrf_token()); ?>",
            columns: [
                {
                    title: "No.",
                    data: "pe_id",
                    className: "column_number text-center",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    },
                },
                {
                    title: "Tanggal",
                    data: "pe_date",
                    className: "column_pe_date",
                },
                {
                    title: "Subjek Pesan",
                    data: "pe_subject",
                    className: "column_pe_subject",
                },
                {
                    title: "Dari",
                    data: "pe_fromaddress",
                    className: "column_pe_fromaddress",
                },
                {
                    title: "Aksi",
                    data: "pe_msgno",
                    className: "column_action",
                    render: function (data, type, row, meta) {
                        var url = "<?php echo e(route('inbox.reademail',':msg')); ?>";
                        url = url.replace(":msg", data);

                        var html = "<div class='d-flex'>";
                        html +=
                            `
                                <a href="` + url + `" class="btn btn-sm btn-icon btn-bg-light btn-icon-success" title="Baca Email">
                                    <i class="ri-eye-fill align-bottom me-1"></i>
                                </a>`;

                        html += "</div>";
                        return html;
                    },
                },
            ],
            buttons: "default",
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/dashboard/email/index.blade.php ENDPATH**/ ?>