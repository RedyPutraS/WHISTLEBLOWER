<?php $__env->startSection('content'); ?>
    <article class="post-63 page type-page status-publish hentry">
        <div class="entry-content container">
            <div class="pb-5">
                <?php if($cms['Kata Pengantar']): ?>
                    <?php echo $cms['Kata Pengantar']; ?>

                <?php else: ?>
                    <h4 class="vc_custom_heading">
                        Form Pengaduan
                    </h4>
                    <p>
                        Jangan khawatir! Kami akan menjamin kerahasiaan identitas diri anda sebagai whistleblower. Laporan dapat disampaikan dengan nama samaran/alias.
                    </p>
                <?php endif; ?>
            </div>
            <div class="my-3">
                <form action="<?php echo e(route('storereport')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Nama & Instansi Pelapor *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_nama" id="f_nama" class="form-control" value="<?php echo e(old('f_nama')); ?>">
                            <?php $__errorArgs = ['f_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    No. Telepon/HP *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="tel" name="f_no_telepon" id="f_no_telepon" class="form-control" value="<?php echo e(old('f_no_telepon')); ?>">
                            <?php $__errorArgs = ['f_no_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Email *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_email" id="f_email" class="form-control" value="<?php echo e(old('f_email')); ?>">
                            <?php $__errorArgs = ['f_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="my-3">
                        <p class="mb-0">
                            *) bila tidak berkenan, dapat dikosongkan
                        </p>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Waktu Kejadian
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_waktu_kejadian" id="f_waktu_kejadian" class="form-control" value="<?php echo e(old('f_waktu_kejadian')); ?>">
                            <small class="text-muted">Waktu diisi secara detail, contoh: Hari Senin 20 Desember 2022 pukul 17:00</small>
                            <?php $__errorArgs = ['f_waktu_kejadian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Tempat Kejadian
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_tempat_kejadian" id="f_tempat_kejadian" class="form-control" value="<?php echo e(old('f_tempat_kejadian')); ?>">
                            <?php $__errorArgs = ['f_tempat_kejadian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Kronologi
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <textarea name="f_kronologi" id="f_kronologi" class="form-control ckeditor" rows="7"><?php echo e(old('f_kronologi')); ?></textarea>
                            <?php $__errorArgs = ['f_kronologi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <div class="row align-items-center">
                                <div class="col-11">
                                    <label>
                                        Unggah Bukti
                                    </label>
                                    <p class="small">
                                        Dapat berupa dokumen, foto, video dan audio. Ukuran file maksimal <?php echo e($filesizelimit); ?>kb!
                                    </p>
                                </div>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="d-flex align-items-center file-evidence">
                                <div style="min-width: 30px;">
                                    <label class="file-evidence-number h4">
                                        1.
                                    </label>
                                </div>
                                <div class="w-100">
                                    <input type="file" name="fb_file_bukti[]" class="form-control-file">
                                    <?php $__errorArgs = ['fb_file_bukti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <label class="file-evidence-number-current mr-4 h4">
                                    2.
                                </label>
                                <div class="w-100">
                                   <button type="button" class="btn btn-flat btn-square mr-2" id="addEvidence">
                                        <i class="fa fa-fw fa-plus"></i>
                                    </button>
                                    <label>
                                        Tambah Bukti
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="my-3 text-right pull-right">
                        <div class="mb-2">
                            <?php echo NoCaptcha::display(); ?>

                            <?php echo NoCaptcha::renderJs(); ?>

                        </div>
                        <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3-size-md btn-rounded-sm cmt-vc_btn3-style-flat cmt-vc_btn3-weight-no cmt-vc_btn3-color-skincolor" title="Buat Laporan">
                            Kirim Laporan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/front/css/bootstrap-timepicker.min.css')); ?>" rel="stylesheet" type="text/css" />
    <style>
        .ck-content {
            height: 340px!important;
        }
        .cke_chrome {
            border: 1px solid rgba(252, 106, 32, 1)!important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/front/js/bootstrap-timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dashboard/js/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        CKEDITOR.replace('.ckeditor');
        CKEDITOR.config.allowedContent = true;
        CKEDITOR.config.removeFormatAttributes = '';
    </script>
    <script>
        var number = 1;
        var lastnumber = 2;
        $('#addEvidence').on('click', function () {
            number++;
            lastnumber++;
            
            $('.file-evidence-number-current').text(lastnumber+".");
            $('.file-evidence:first').clone().find('.file-evidence-number').text(number+".").end().find('input').val('').end().insertAfter(".file-evidence:last");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/front/createreport.blade.php ENDPATH**/ ?>