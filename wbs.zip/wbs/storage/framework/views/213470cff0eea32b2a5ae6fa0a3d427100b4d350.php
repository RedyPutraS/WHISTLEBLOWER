<?php $__env->startSection('content'); ?>
    <div class="content__header content__boxed overlapping mb-4">
        <div class="content__wrap">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="ri-home-4-line"></i>
                        </a>
                    </li>
                    <li class="breadcrumb-item active" >
                        Pengaduan
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Cetak Berkas
                    </li>
                </ol>
            </nav>
            <h1 class="page-title mt-4">
                Pengaduan
            </h1>
            <p class="lead">
                Cetak berkas pengaduan secara lengkap
            </p>
        </div>
    </div>
    <div class="content__boxed">
        <div class="content__wrap">
            <div class="bg-white p-3 mt-4 print-container">

                <div class="col-md-6 mx-auto mb-5">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-2 text-right">
                            <img src="<?php echo e(asset('assets/dashboard/images/logomnk.png')); ?>" height="75">
                        </div>
                        <div class="col-6">
                            <h2 class="font-weight-bold lh-1">
                                PT. Multi Nitrotama Kimia
                            </h2>
                            <h6 class="mb-1">
                                Jl. Jend. Sudirman Kav. 52-53 Lot 9, Jakarta, 12190
                            </h6>
                            <h6 class="mb-0">
                                Telp : (+62-21) 2903 5022 (Hunting) |
                                Fax : (+62-21) 2903 5021
                            </h6>
                        </div>
                    </div>
                </div>

                <div class="text-center pb-4">
                    <h3 class="font-weight-bold mb-1">
                        Berkas Pengaduan
                    </h3>
                    <h6>
                        No. <?php echo e($complaint->f_noreg); ?>

                    </h6>
                </div>

                <div class="pb-4">
                    <h4 class="font-weight-bold mb-3 underline">
                        <u>
                            Rincian Pengaduan :
                        </u>
                    </h4>
                    <ul class="ps-0 mb-4">
                        <li class="row">
                            <div class="col-3">
                                Nama & Instansi
                            </div>
                            <div class="col-9">
                                :
                                <?php if($complaint->f_nama): ?>
                                    <?php echo e($complaint->f_nama); ?>

                                <?php else: ?>
                                    Anonim [Identitas Dirahasiakan]
                                <?php endif; ?>
                            </div>
                        </li>
                        <li class="row">
                            <div class="col-3">
                                No. Telepon/HP
                            </div>
                            <div class="col-9">
                                :
                                <?php if($complaint->f_no_telepon): ?>
                                    <?php echo e($complaint->f_no_telepon); ?>

                                <?php else: ?>
                                    Anonim [Identitas Dirahasiakan]
                                <?php endif; ?>
                            </div>
                        </li>
                        <li class="row">
                            <div class="col-3">
                                Email
                            </div>
                            <div class="col-9">
                                :
                                <?php if($complaint->f_email): ?>
                                    <?php echo e($complaint->f_email); ?>

                                <?php else: ?>
                                    Anonim [Identitas Dirahasiakan]
                                <?php endif; ?>
                            </div>
                        </li>
                        <li class="row">
                            <div class="col-3">
                                Waktu Kejadian
                            </div>
                            <div class="col-9">
                                :
                                <?php echo e($complaint->f_waktu_kejadian); ?>

                            </div>
                        </li>
                        <li class="row">
                            <div class="col-3">
                                Tempat Kejadian
                            </div>
                            <div class="col-9">
                                :
                                <?php echo e($complaint->f_tempat_kejadian); ?>

                            </div>
                        </li>
                    </ul>
                    <div class="text-justify mb-4">
                        <p class="mb-1">
                            Kronologi :
                        </p>
    
                        <?php echo $complaint->f_kronologi; ?>

                    </div>
                    <div class="mb-4">
                        <p class="mb-1">
                            Bukti Awal:
                        </p>
                        <?php if(count($complaint->formulirpengaduan_buktiawal) > 0): ?>
                            <ol type="1" class="ps-3">
                                <?php $__currentLoopData = $complaint->formulirpengaduan_buktiawal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($evidence->attachment); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        <?php else: ?>
                            <div class="badge bg-danger text-white">Bukti tidak diunggah</div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-4">
                        <p class="mb-1">
                            Bukti Tambahan:
                        </p>
                        <?php if(count($complaint->formulirpengaduan_buktitambahan) > 0): ?>
                            <ol type="1" class="ps-3">
                                <?php $__currentLoopData = $complaint->formulirpengaduan_buktitambahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $evidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($evidence->attachment); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        <?php else: ?>
                            <div class="badge bg-danger text-white">Bukti tidak diunggah</div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="pb-4">
                    <h4 class="font-weight-bold mb-3 underline">
                        <u>
                            Riwayat Perkembangan Pengaduan :
                        </u>
                    </h4>
                    <div class="timeline pb-4">
                        <?php $__currentLoopData = $complaint->formulirpengaduan_riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tl-entry active">
                                <div class="tl-time">
                                    <div class="tl-date">
                                        <?php echo e(\Carbon\Carbon::parse($history->created_at)->translatedFormat('d M Y')); ?>

                                    </div>
                                    <div class="tl-time">
                                        <?php echo e(\Carbon\Carbon::parse($history->created_at)->translatedFormat('H:i')); ?>

                                    </div>
                                </div>
                                <div class="tl-point"></div>
                                <div class="tl-content">
                                    <?php echo e($history->fr_keterangan); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="pb-4 pt-4 pagebreak">
                    <h4 class="font-weight-bold mb-3 underline">
                        <u>
                            Diskusi dengan Investigator :
                        </u>
                    </h4>
                    <div class="mt-4" id="chat-card">
                        <?php if(count($complaint->diskusi)): ?>
                            <?php $__currentLoopData = $complaint->diskusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diskusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card my-4 shadow">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center">
                                            <div class="col-1 d-none d-lg-block">
                                                <i class="ri-user-3-fill" style="font-size: 25px;"></i>
                                            </div>
                                            <div class="col-11">
                                                <div class="row mb-4">
                                                    <div class="col-8">
                                                        <h5 class="mb-0">
                                                            <?php echo e($diskusi->d_nama); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="col-4 text-end">
                                                        <h5 class="mb-0">
                                                            <?php echo e(\Carbon\Carbon::parse($diskusi->d_waktu)->translatedFormat('d F Y H:i')); ?>

                                                        </h5>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <?php echo e($diskusi->rd_pesan); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h5 class="my-4">
                                Belum ada diskusi tanya jawab.
                            </h5>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .print-container div, .print-container p, .print-container h1, .print-container h2, .print-container h3, .print-container h4, .print-container h5, .print-container h6 {
            color: #373c43;
            font-weight: 500;
            font-family: "Work Sans", Arial, Helvetica, sans-serif;
        }

        @page  {
            margin: 1cm;
        }
        
        @media  print {
            .pagebreak { page-break-before: always; } /* page-break-after works, as well */
            #exclude-from-print {
                display: none;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        window.print();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/dashboard/complaint/print.blade.php ENDPATH**/ ?>