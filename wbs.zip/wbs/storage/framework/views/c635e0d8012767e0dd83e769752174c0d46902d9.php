<div class="content__boxed">
    <div class="content__wrap py-3 py-md-1 d-flex flex-column flex-md-row align-items-md-center">
        <div class="text-nowrap mb-4 mb-md-0">
            Copyright &copy; 2022
            <a href="https://mnk.co.id/" class="ms-1 btn-link fw-bold">
                PT. Multi Nitrotama Kimia (MNK)
            </a>
        </div>
        <nav class="nav flex-column gap-1 flex-md-row gap-md-3 ms-md-auto" style="row-gap: 0 !important;">
            <a class="nav-link px-0" href="<?php echo e(route('help')); ?>">
                <i class="ri-information-line align-middle"></i>
                Bantuan
            </a>
        </nav>
    </div>
</div><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/dashboard/master/components/footer.blade.php ENDPATH**/ ?>