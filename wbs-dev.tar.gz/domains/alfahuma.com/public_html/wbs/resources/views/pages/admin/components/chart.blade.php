<div class="card mt-5 shadow">
    <div class="card-body">
        <div class="card-header bg-transparent">
            <p class="title">Pengaduan masuk dan selesai per bulan</p>
        </div>
        <div class="chart-container">
            <div style="width: 70%; margin: auto; height: auto;">
                <canvas id="myChart"></canvas>
            </div>
        </div>
    </div>
</div>