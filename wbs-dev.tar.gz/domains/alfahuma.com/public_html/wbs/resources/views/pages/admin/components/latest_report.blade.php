<div class="table-responsive mt-5">
    <table class="table">
        <thead>
            <tr class="fw-bold">
                <th>#</th>
                <th>Tgl. Masuk</th>
                <th>Pelapor</th>
                <th>No. Laporan</th>
                <th>Status Terakhir</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="fw-bold">1</td>
                <td>20 Nov 2022</td>
                <td>detektifconan - Pajak</td>
                <td>WRK6JB/2022</td>
                <td>Kurang Bukti</td>
            </tr>
            <tr>
                <td class="fw-bold">1</td>
                <td>22 Nov 2022</td>
                <td>detektifconan - Pajak</td>
                <td>WRK6JB/2022</td>
                <td>Kurang Bukti</td>
            </tr>
            <tr>
                <td class="fw-bold">1</td>
                <td>23 Nov 2022</td>
                <td>detektifconan - Pajak</td>
                <td>WRK6JB/2022</td>
                <td>Kurang Bukti</td>
            </tr>
        </tbody>
    </table>
</div>