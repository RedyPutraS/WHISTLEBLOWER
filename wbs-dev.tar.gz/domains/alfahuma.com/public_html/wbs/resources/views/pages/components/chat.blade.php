<div class="container-message">
    <div class="message-box row border mb-3">
        <div class="col-md-1">
            <i class="bi bi-people" style="font-size: 26px;"></i>
        </div>
        <div class="col-md-11">
            <div class="header pb-1 mb-2 border-bottom d-flex align-items center justify-content-between">
                <p class="name">tim investigator</p>
                <p class="date">01-05-2022</p>
            </div>
            <div class="body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure dolorem recusandae ratione ab consequuntur facilis quibusdam dicta, dolor debitis quo a praesentium eveniet. Consectetur ad minus sunt numquam, rem enim.
            </div>
        </div>
    </div>
    <div class="message-box row border mb-3">
        <div class="col-md-1">
            <i class="bi bi-person" style="font-size: 26px;"></i>
        </div>
        <div class="col-md-11">
            <div class="header pb-1 mb-2 border-bottom d-flex align-items center justify-content-between">
                <p class="name">detektifconan</p>
                <p class="date">01-05-2022</p>
            </div>
            <div class="body">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure dolorem recusandae ratione ab consequuntur facilis quibusdam dicta, dolor debitis quo a praesentium eveniet. Consectetur ad minus sunt numquam, rem enim.
            </div>
        </div>
    </div>
</div>