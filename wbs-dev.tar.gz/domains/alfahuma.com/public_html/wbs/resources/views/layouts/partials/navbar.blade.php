<div class="navbar">
    <div class="navbar-title">
        <p class="title">whistleblower</p>
    </div>
</div>