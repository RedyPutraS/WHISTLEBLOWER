<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'FrontController@index')->name('index');
Route::get('/formpengaduan', 'FrontController@createreport')->name('createreport');
Route::post('/formpengaduan', 'FrontController@storereport')->name('storereport');
Route::post('/tracingreport', 'FrontController@tracereport')->name('tracereport');
Route::get('/tracingreport/{code}', 'FrontController@tracingreport')->name('tracingreport');
Route::get('/detailreport', 'FrontController@detailreport')->name('detailreport');

Auth::routes();

Route::group(['prefix' => 'dashboard', 'as' => 'dashboard.'], function () {
    Route::get('/', 'DashboardController@index')->name('index');
});

Route::group(['prefix' => 'complaint', 'as' => 'complaint.'], function () {
    Route::get('/', 'ComplaintController@index')->name('index');
});

Route::group(['prefix' => 'faq', 'as' => 'faq.'], function () {
    Route::get('/', 'FAQController@index')->name('index');
});

