

<?php $__env->startSection('content'); ?>
    <article id="post-63" class="post-63 page type-page status-publish hentry">
        <div class="entry-content container">
            <div class="pb-5">
                <h4 class="vc_custom_heading">
                    Selamat datang di MNK Whistleblowing System
                </h4>
                <p>
                    MNK Whistleblowing System adalah aplikasi yang disediakan oleh PT. Multi Nitrotama Kimia bagi pihak eksternal dan internal perusahaan,  yang memiliki informasi dan ingin melaporkan suatu perbuatan berindikasi Fraud dan/atau pelanggaran yang terjadi di lingkungan perusahaan.
                </p>
                <p>
                    Anda tidak perlu khawatir terungkapnya identitas diri anda karena PT. Multi Nitrotama Kimia akan merahasiakan identitas diri anda sebagai whistleblower. PT. Multi Nitrotama Kimia menghargai informasi yang Anda laporkan. Fokus kami kepada materi informasi yang Anda Laporkan.
                </p>
            </div>
            <div class="py-5">
                <h4 class="vc_custom_heading">
                    Penyampaian Pelaporan
                </h4>
                <p>
                    Dalam rangka mempermudah dan mempercepat proses tindak lanjut, pengaduan fraud dan/atau pelanggaran yang dilaporkan, sebaiknya dapat memenuhi informasi yang jelas dan dapat dipertanggungjawabkan serta dilengkapi dengan bukti yang relevan, kompeten dan cukup, diantaranya meliputi:
                </p>
                <ul>
                    <li>
                        <b>What:</b> Perbuatan berindikasi pelanggaran yang diketahui
                    </li>
                    <li>
                        <b>Where:</b> Dimana perbuatan tersebut dilakukan
                    </li>
                    <li>
                        <b>When:</b> Kapan perbuatan tersebut dilakukan
                    </li>
                    <li>
                        <b>Who:</b> Siapa saja yang terlibat dalam perbuatan tersebut
                    </li>
                    <li>
                        <b>How:</b> Bagaimana perbuatan tersebut dilakukan (modus, cara, bukti, kerugian, dsb.)
                    </li>
                </ul>
                <p>
                    Selain, dengan dashboard pada web ini pelaporan juga dapat langsung dikirimkan melalui email <b>pengaduan@mnk.co.id</b> dan whatsapp melalui nomor <b>+6281xxxxxxx</b>.
                </p>
            </div>
            <div class="my-3 text-right">
                <a class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3-size-md btn-rounded-sm cmt-vc_btn3-style-flat cmt-vc_btn3-weight-no cmt-vc_btn3-color-skincolor" href="#" title="Buat Laporan">
                
                    Buat Laporan
                </a>
            </div>
            <div class="py-5">
                <h4 class="vc_custom_heading">
                    Tindak Lanjut
                </h4>
                <p>
                    Apabila Bapak/Ibu ingin mengetahui status, perkembangan dan tindak lanjut atas laporan yang telah dibuat, dapat menginput nomor laporan pengaduan pada menu di bawah ini:
                </p>
            </div>
            <div class="my-2">
                <form action="#" method="post">
                
                    <?php echo csrf_field(); ?>
                    <div class="row align-items-center">
                        <div class="col-lg-2">
                            <label>
                                No. Laporan:
                            </label>
                        </div>
                        <div class="col-lg-8 col-8">
                            <input type="text" name="code" id="code" class="form-control">
                        </div>
                        <div class="col-lg-2 col-4">
                            <button type="submit" class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3-size-md btn-rounded-sm cmt-vc_btn3-style-flat cmt-vc_btn3-weight-no cmt-vc_btn3-color-skincolor w-100" title="Lacak Laporan">
                                Lacak
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\Whistleblower\resources\views/front/index.blade.php ENDPATH**/ ?>