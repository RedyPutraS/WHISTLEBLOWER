<?php $__env->startSection('content'); ?>
    <article class="post-63 page type-page status-publish hentry">
        <div class="entry-content container">
            <div class="pb-5">
                <h4 class="vc_custom_heading">
                    Form Pengaduan
                </h4>
                <p>
                    Jangan khawatir! Kami akan menjamin kerahasiaan identitas diri anda sebagai whistleblower. Laporan dapat disampaikan dengan nama samaran/alias.
                </p>
            </div>
            <div class="my-3">
                <form action="<?php echo e(route('storereport')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Nama & Instansi Pelapor *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_nama" id="f_nama" class="form-control" value="<?php echo e(old('f_nama')); ?>">
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    No. Telepon/HP *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="tel" name="f_no_telepon" id="f_no_telepon" class="form-control" value="<?php echo e(old('f_no_telepon')); ?>">
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Email *)
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_email" id="f_email" class="form-control" value="<?php echo e(old('f_email')); ?>">
                        </div>
                    </div>
                    <div class="my-3">
                        <p class="mb-0">
                            *) bila tidak berkenan, dapat dikosongkan
                        </p>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Waktu Kejadian
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_waktu_kejadian" id="f_waktu_kejadian" class="form-control" value="<?php echo e(old('f_waktu_kejadian')); ?>">
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Tempat Kejadian
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <input type="text" name="f_tempat_kejadian" id="f_tempat_kejadian" class="form-control" value="<?php echo e(old('f_tempat_kejadian')); ?>">
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row">
                                <label class="col-11">
                                    Kronologi
                                </label>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <textarea name="f_tempat_kejadian" id="f_tempat_kejadian" class="form-control" rows="7"><?php echo e(old('f_tempat_kejadian')); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row align-items-center">
                        <div class="col-md-4">
                            <div class="row align-items-center">
                                <div class="col-11">
                                    <label>
                                        Unggah Bukti
                                    </label>
                                    <p class="small">
                                        Dapat berupa dokumen, foto, video dan audio
                                    </p>
                                </div>
                                <div class="col-1 d-none d-lg-block font-weight-bold">
                                    :
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="d-flex align-items-center">
                                <label class="file-number-increment mr-4 h4">
                                    1.
                                </label>
                                <div class="w-100">
                                    <input type="file" name="fb_file_bukti" id="fb_file_bukti" class="form-control-file" value="<?php echo e(old('fb_file_bukti')); ?>">
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <label class="file-number-increment mr-4 h4">
                                    2.
                                </label>
                                <div class="w-100">
                                   <button type="button" class="btn btn-flat mr-2">
                                        <i class="fa fa-fw fa-plus"></i>
                                    </button>
                                    <label>
                                        Tambah Bukti
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="my-3 text-right pull-right">
                        <div class="mb-2">
                            <?php echo NoCaptcha::display(); ?>

                            <?php echo NoCaptcha::renderJs(); ?>

                        </div>
                        <a class="cmt-vc_general cmt-vc_btn3 cmt-vc_btn3-size-md btn-rounded-sm cmt-vc_btn3-style-flat cmt-vc_btn3-weight-no cmt-vc_btn3-color-skincolor" href="<?php echo e(route('createreport')); ?>" title="Buat Laporan">
                            Kirim Laporan
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfahum1/domains/alfahuma.com/public_html/wbs/resources/views/front/createreport.blade.php ENDPATH**/ ?>