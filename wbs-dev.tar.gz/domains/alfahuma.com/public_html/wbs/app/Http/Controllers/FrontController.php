<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function index(){
        return view('front.index');
    }

    public function createreport(){
        return view('front.createreport');
    }

    public function storereport(Request $request)
    {
        # code...
    }

    public function tracingreport(){
        return "Halaman Front Tracing Laporan" ;
    }

    public function detailreport(){
        return "Halaman Front Detail Laporan" ;
    }

}
