<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Formulirpengaduan extends Model
{
    protected $table = 'formulir_pengaduan';
    protected $primaryKey = 'p_id';
    protected $guarded = [];
}
